import React, { useState } from 'react'; // Import useState
import './verticalNavbar.css';
import { Link } from 'react-router-dom';
import DashboardRoundedIcon from '@mui/icons-material/DashboardRounded';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import CollectionsBookmarkIcon from '@mui/icons-material/CollectionsBookmark';

function VerticalNavbar({ onClose }) {
    const [activeLink, setActiveLink] = useState(null);
    const [divOpen,setDivOpen] = useState(false);
    const [creditOpen,setCreditOpen] = useState(false)
    const [addOnOpen,setAddOnOpen] = useState(false)
    const [internOpen,setInternOpen] = useState(false)
    const handleLinkClick = (pathname) => {
        onClose();
        setActiveLink(pathname);
    };
    const handleOpen = () => {
        setDivOpen(!divOpen);
    }
    const handleOneCreditOpen = () => {
        setCreditOpen(!creditOpen)
    }
    const handleAddOnOpenOpen = () => {
        setAddOnOpen(!addOnOpen)
    }
    const handleInternOpen = () => {
        setInternOpen(!internOpen)
    }

    return (
        <div className='total-v-navbar'>
            <div className={`menu-item ${activeLink === '/' ? 'active' : ''}`} onClick={() => handleLinkClick('/')}>
                <Link to="/" className="link-style"><DashboardRoundedIcon className='nav-icons' />Dashboard</Link>
            </div>
            <div className='groups'>-- Course Exemption --</div>
            <div className={`menu-item ${activeLink === '/courseExcp' ? 'active' : ''}`} onClick={() => handleLinkClick('/courseExcp')}>
                <Link to="/courseExcp" className="link-style"><DashboardRoundedIcon className='nav-icons' />Course Exemption</Link>
            </div>
            <div className={`menu-item ${activeLink === '' ? 'active' : ''}`} onClick={() => handleOpen( )}>
                <Link className="link-style"><DashboardRoundedIcon className='nav-icons' />OnlineCourse{divOpen?<KeyboardArrowUpIcon />:<KeyboardArrowDownIcon/>} </Link>
            </div>
            {divOpen && 
            <div className='options'>
            <div className={`menu-items ${activeLink === '/courseApproval' ? 'active' : ''}`} onClick={() => handleLinkClick('/courseApproval')}>
                <Link to="/courseApproval" className="link-style"><DashboardRoundedIcon className='nav-icons' />Pending Courses</Link>
            </div>
            <div className={`menu-items ${activeLink === '/OnlineReports' ? 'active' : ''}`} onClick={() => handleLinkClick('/OnlineReports')}>
                <Link to="/OnlineReports" className="link-style"><DashboardRoundedIcon className='nav-icons' />ApprovedCourses</Link>
            </div>
            <div className={`menu-items ${activeLink === '/OnlineRejected' ? 'active' : ''}`} onClick={() => handleLinkClick('/OnlineRejected')}>
                <Link to="/OnlineRejected" className="link-style"><DashboardRoundedIcon className='nav-icons' />Rejected Courses</Link>
            </div>
            <div className={`menu-items ${activeLink === '/OnlineUpload' ? 'active' : ''}`} onClick={() => handleLinkClick('/OnlineUpload')}>
                <Link to="/OnlineUpload" className="link-style"><DashboardRoundedIcon className='nav-icons' />Online Upload</Link>
            </div>
            <div className={`menu-items ${activeLink === '/OnlineCourseList' ? 'active' : ''}`} onClick={() => handleLinkClick('/OnlineCourseList')}>
                <Link to="/OnlineCourseList" className="link-style"><DashboardRoundedIcon className='nav-icons' />List Of Courses</Link>
            </div>
            </div> }
            <div className={`menu-item ${activeLink === '' ? 'active' : ''}`} onClick={() => handleOneCreditOpen( )}>
                <Link className="link-style"><DashboardRoundedIcon className='nav-icons' />OneCredit{creditOpen?<KeyboardArrowUpIcon />:<KeyboardArrowDownIcon/>} </Link>
            </div>
            {creditOpen&&
            <div className='options'>
                <div className={`menu-items ${activeLink === '/OneCreditPending' ? 'active' : ''}`} onClick={() => handleLinkClick('/OneCreditPending')}>
                <Link to="/OneCreditPending" className="link-style"><DashboardRoundedIcon className='nav-icons' />Pending Approvals</Link>
                </div>
                <div className={`menu-items ${activeLink === '/OneCreditApproved' ? 'active' : ''}`} onClick={() => handleLinkClick('/OneCreditApproved')}>
                <Link to="/OneCreditApproved" className="link-style"><DashboardRoundedIcon className='nav-icons' />ApprovedCourses</Link>
                </div>
                <div className={`menu-items ${activeLink === '/OneCreditRejected' ? 'active' : ''}`} onClick={() => handleLinkClick('/OneCreditRejected')}>
                <Link to="/OneCreditRejected" className="link-style"><DashboardRoundedIcon className='nav-icons' />Rejected Courses</Link>
                </div>
                <div className={`menu-items ${activeLink === '/OneCreditUpload' ? 'active' : ''}`} onClick={() => handleLinkClick('/OneCreditUpload')}>
                <Link to="/OneCreditUpload" className="link-style"><DashboardRoundedIcon className='nav-icons' />One Credit Upload</Link>
                </div>
                <div className={`menu-items ${activeLink === '/OneCreditMappings' ? 'active' : ''}`} onClick={() => handleLinkClick('/OneCreditMappings')}>
                <Link to="/OneCreditMappings" className="link-style"><DashboardRoundedIcon className='nav-icons' />One Credit Courses/students</Link>
                </div>
            </div>
            }
            <div className={`menu-item ${activeLink === '' ? 'active' : ''}`} onClick={() => handleAddOnOpenOpen( )}>
                <Link className="link-style"><DashboardRoundedIcon className='nav-icons' />Add-On/Honor Minor{addOnOpen?<KeyboardArrowUpIcon />:<KeyboardArrowDownIcon/>} </Link>
            </div>
            {addOnOpen && 
            <div className='options' >
                <div className={`menu-items ${activeLink === '/AddonPending' ? 'active' : ''}`} onClick={() => handleLinkClick('/AddonPending')}>
                <Link to="/AddonPending" className="link-style"><DashboardRoundedIcon className='nav-icons' />Pending Approvals</Link>
                </div>
                <div className={`menu-items ${activeLink === '/AddonApproved' ? 'active' : ''}`} onClick={() => handleLinkClick('/AddonApproved')}>
                <Link to="/AddonApproved" className="link-style"><DashboardRoundedIcon className='nav-icons' />ApprovedCourses</Link>
                </div>
                <div className={`menu-items ${activeLink === '/AddonRejected' ? 'active' : ''}`} onClick={() => handleLinkClick('/AddonRejected')}>
                <Link to="/AddonRejected" className="link-style"><DashboardRoundedIcon className='nav-icons' />Rejected Courses</Link>
                </div>
                <div className={`menu-items ${activeLink === '/AddOnUpload' ? 'active' : ''}`} onClick={() => handleLinkClick('/AddOnUpload')}>
                <Link to="/AddOnUpload" className="link-style"><DashboardRoundedIcon className='nav-icons' />Add-On Upload</Link>
                </div>
                <div className={`menu-items ${activeLink === '/HonorMinorUpload' ? 'active' : ''}`} onClick={() => handleLinkClick('/HonorMinorUpload')}>
                <Link to="/HonorMinorUpload" className="link-style"><DashboardRoundedIcon className='nav-icons' />Honor Minor Upload</Link>
                </div>
                <div className={`menu-items ${activeLink === '/ListOfStudentsMappings' ? 'active' : ''}`} onClick={() => handleLinkClick('/ListOfStudentsMappings')}>
                <Link to="/ListOfStudentsMappings" className="link-style"><DashboardRoundedIcon className='nav-icons' />List Of Student Mappings</Link>
                </div>
            </div>
            }
            <div className={`menu-item ${activeLink === '' ? 'active' : ''}`} onClick={() => handleInternOpen( )}>
                <Link className="link-style"><DashboardRoundedIcon className='nav-icons' />InternShips{internOpen?<KeyboardArrowUpIcon />:<KeyboardArrowDownIcon/>} </Link>
            </div>
            {internOpen &&
            <div className='options'>
                <div className={`menu-items ${activeLink === '/InternPending' ? 'active' : ''}`} onClick={() => handleLinkClick('/InternPending')}>
                <Link to="/InternPending" className="link-style"><DashboardRoundedIcon className='nav-icons' />Pending Approvals</Link>
                </div>
                <div className={`menu-items ${activeLink === '/InternApproved' ? 'active' : ''}`} onClick={() => handleLinkClick('/InternApproved')}>
                <Link to="/InternApproved" className="link-style"><DashboardRoundedIcon className='nav-icons' />ApprovedCourses</Link>
                </div>
                <div className={`menu-items ${activeLink === '/InternRejected' ? 'active' : ''}`} onClick={() => handleLinkClick('/InternRejected')}>
                <Link to="/InternRejected" className="link-style"><DashboardRoundedIcon className='nav-icons' />Rejected Courses</Link>
                </div>
                <div className={`menu-items ${activeLink === '/InternUpload' ? 'active' : ''}`} onClick={() => handleLinkClick('/InternUpload')}>
                <Link to="/InternUpload" className="link-style"><DashboardRoundedIcon className='nav-icons' />InternShip Upload</Link>
                </div>
                <div className={`menu-items ${activeLink === '/InternCompanyList' ? 'active' : ''}`} onClick={() => handleLinkClick('/InternCompanyList')}>
                <Link to="/InternCompanyList" className="link-style"><DashboardRoundedIcon className='nav-icons' />InternShip Company List</Link>
                </div>
            </div>
            }
            <div className={`menu-item ${activeLink === '/OveralReports' ? 'active' : ''}`} onClick={() => handleLinkClick('/OveralReports')}>
                <Link to="/OveralReports" className="link-style"><DashboardRoundedIcon className='nav-icons' />Overal Reports</Link>
            </div>
            
        </div>
    );
}

export default VerticalNavbar;

