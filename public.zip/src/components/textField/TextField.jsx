import React from 'react'

const TextField = () => {
  return (
    <div>
      <input 
      className='textField'
      type="text" />
    </div>
  )
}

export default TextField
