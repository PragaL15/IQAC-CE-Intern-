const ipAddress = 'http://localhost:5001';

export const apiBaseUrl = ipAddress;