import './App.css'
import AppLayout from './components/appLayout/appLayout'

function App() {
  return (
    <>
      <AppLayout />
    </>
  )
}

export default App
