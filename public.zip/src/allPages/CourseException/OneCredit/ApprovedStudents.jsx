import React from 'react'

const ApprovedStudents = () => {
  return (
    <div>
      Approved Students OneCredit
    </div>
  )
}

export default ApprovedStudents
