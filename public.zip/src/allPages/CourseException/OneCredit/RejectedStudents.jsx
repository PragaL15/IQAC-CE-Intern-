import React from 'react'

const RejectedStudents = () => {
  return (
    <div>
      Rejected Students OneCredit
    </div>
  )
}

export default RejectedStudents
