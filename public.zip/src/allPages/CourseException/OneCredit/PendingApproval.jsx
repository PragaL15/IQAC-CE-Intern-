import React from 'react'

const PendingApproval = () => {
  return (
    <div>
      Pending Approval OneCredit
    </div>
  )
}

export default PendingApproval
