import React from 'react'

const DispCard = () => {
  return (
    <div>DispCard</div>
  )
}

export default DispCard