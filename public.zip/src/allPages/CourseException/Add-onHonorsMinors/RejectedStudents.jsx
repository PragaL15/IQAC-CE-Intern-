import React from 'react'

const RejectedStudents = () => {
  return (
    <div>
      Rejected Students Add-on Honor Minor
    </div>
  )
}

export default RejectedStudents
