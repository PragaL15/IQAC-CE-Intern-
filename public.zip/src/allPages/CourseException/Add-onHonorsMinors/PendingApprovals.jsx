import React from 'react'

const PendingApprovals = () => {
  return (
    <div>
      Pending Approval Add-on Honor Minor
    </div>
  )
}

export default PendingApprovals
