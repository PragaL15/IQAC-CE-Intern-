import React from 'react'

const ApprovedStudents = () => {
  return (
    <div>
      Approved Students Add-on Honor Minor
    </div>
  )
}

export default ApprovedStudents
