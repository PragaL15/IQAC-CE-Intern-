import React from 'react'

const PendingApprovals = () => {
  return (
    <div>
      Pending Approval Internship
    </div>
  )
}

export default PendingApprovals
