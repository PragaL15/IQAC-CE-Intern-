import React from 'react'

const RejectedStudents = () => {
  return (
    <div>
      Rejected Students Internship
    </div>
  )
}

export default RejectedStudents
