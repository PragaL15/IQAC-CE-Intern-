import React from 'react'

const ApprovedStudents = () => {
  return (
    <div>
      Aprroval Students Internship
    </div>
  )
}

export default ApprovedStudents
